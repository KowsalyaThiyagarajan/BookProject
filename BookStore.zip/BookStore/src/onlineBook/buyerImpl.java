package onlineBook;

import java.util.ArrayList;
import java.util.List;

class Book {
	String Name, Author;
	double price;
	int BookId;

	public Book(int BookId, String Name, String Author, double price) {
		this.BookId = BookId;
		this.Name = Name;
		this.Author = Author;
		this.price = price;

	}
}

public class buyerImpl {
	private List<Book> Bookadd;// holds the obj of book class

	public buyerImpl() {
		Bookadd = new ArrayList<>();// intializes the bookList variable with a new instance of the ArrayList class

		Book b1 = new Book(1, "Wings Of Fire", "Dr.APJ.Abdul Kalam", 195.0);
		Book b2 = new Book(2, "Changing India", "Dr. Manmohan Singh", 120.0);
		Book b3 = new Book(3, "The Psychology of Money", "Morgan Housel", 210.0);
		Book b4 = new Book(4, "To Kill a Mockingbird", "Harper Lee", 225.0);
		Book b5 = new Book(5, "Ponniyin Selvan", " Kalki Krishnamurthy", 550.0);

		Bookadd.add(b1);
		Bookadd.add(b2);
		Bookadd.add(b3);
		Bookadd.add(b4);
		Bookadd.add(b5);
	}

	public List<Book> getBookadd() {
		return Bookadd;
	}
}