package onlineBook;

import java.util.Scanner;

public class MainBook {

	public static void main(String[] args) {
		BookCollection OB = new BookCollection();

		String username = "bookStore@123";
		int pwd = 123;

		Scanner sc = new Scanner(System.in);
		System.out.println("Welcome to Online Book Store");

		System.out.println("Enter Your Email:");
		String enteredUsername = sc.nextLine();

		System.out.println("Enter Your Password:");
		int EnteredPassword = sc.nextInt();
		if (enteredUsername.equals(username)) {
			while (true) {

				System.out.println("1.Buyer\n 2.Seller\n 3.Exit");
				System.out.println("Enter Your Choice:");
				int ch = sc.nextInt();
				sc.nextLine();
				if (ch == 1) {

					OB.bookTitle();
					OB.selectedBook();
					OB.buyingQuantity();
					OB.homeDelivey();

					System.out.println("Thank You for Choosing Us....");
					System.out.println("ORDERED CONFIRM...");
					System.out.println("------------------------------------------------------------");

				} else if (ch == 2) {

					OB.bookTitle();
					OB.available();
					OB.buyerDetails();
					System.out.println("------------------------------------------------------------");

				}
			}
		} else {
			System.out.println("Incorrect Email or Password");
		}
	}

}
