package onlineBook;

import java.util.*;

public class BookCollection implements BookInterfaceBuyer {
	buyerImpl buying = new buyerImpl();// instance of class
	Buyer buy = new Buyer();

	List<Book> Bookadd = buying.getBookadd();

	@Override
	public void bookTitle() {
		for (Book book : Bookadd) {
			System.out.println("Book ID:" + book.BookId);
			System.out.println("Book Name: " + book.Name);
			System.out.println("Author: " + book.Author);
			System.out.println("Price: " + book.price);
			System.out.println();
		}

	}

	@Override
	public void buyingQuantity() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Buying Quantity:");
		int quantity = sc.nextInt();
		buy.setBuyingQuantity(quantity);

	}

	@Override
	public void selectedBook() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your choice of Book:");
		int ch = sc.nextInt();

		switch (ch) {
		case 01:
			System.out.println("Selected Book is Wings Of Fire");
			break;
		case 02:
			System.out.println("Selected Book is Changing India");
			break;
		case 03:
			System.out.println("Selected Book is The Psychology of Money");
			break;
		case 04:
			System.out.println("Selected Book is To Kill a Mockingbird");
			break;
		case 05:
			System.out.println("Selected Book is Ponniyin Selvan");
			break;
		default:
			System.out.println("Invalid choice");

		}

	}

	@Override
	public void homeDelivey() {
		Scanner sc = new Scanner(System.in);
		System.out.println("To Confirm Your Order Enter the below Details for Delivery to your Home Step!!");
		System.out.println("Enter Your Address:");
		String address = sc.next();
		buy.setBuyeraddress(address);
		System.out.println("Enter Your Name:");
		String name = sc.next();
		buy.setBuyername(name);
		System.out.println("Enter Your Phone Number:");
		String phone = sc.next();
		buy.setBuyerPhone(phone);

	}

	@Override
	public void available() {
		buy.setAvailableQuantity(50);
		System.out.println("Total Book left:" + (buy.getAvailableQuantity() - buy.getBuyingQuantity()));
		
	}

	@Override
	public void buyerDetails() {
		System.out.println("Buyer Name:" + buy.getBuyername());
		System.out.println("Buyer Address:" + buy.getBuyeraddress());
		System.out.println("Buyer Phone:" + buy.getBuyerPhone());

	}

}
