package onlineBook;

public class Buyer {
	private int buyingQuantity;
	private int availableQuantity;
	private String buyername;
	private String buyeraddress;
	private String buyerPhone;

	public Buyer() {

	}

	public int getBuyingQuantity() {
		return buyingQuantity;
	}

	public void setBuyingQuantity(int buyingQuantity) {
		this.buyingQuantity = buyingQuantity;
	}

	public int getAvailableQuantity() {
		return availableQuantity;
	}

	public void setAvailableQuantity(int availableQuantity) {
		this.availableQuantity = availableQuantity;

	}

	public String getBuyername() {
		return buyername;
	}

	public void setBuyername(String buyername) {
		this.buyername = buyername;
	}

	public String getBuyeraddress() {
		return buyeraddress;
	}

	public void setBuyeraddress(String buyeraddress) {
		this.buyeraddress = buyeraddress;
	}

	public String getBuyerPhone() {
		return buyerPhone;
	}

	public void setBuyerPhone(String buyerPhone) {
		this.buyerPhone = buyerPhone;
	}

}
