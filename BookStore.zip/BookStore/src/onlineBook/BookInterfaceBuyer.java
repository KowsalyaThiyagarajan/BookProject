package onlineBook;

public interface BookInterfaceBuyer {
	public void bookTitle();

	public void selectedBook();

	public void buyingQuantity();

	public void homeDelivey();

	public void available();

	public void buyerDetails();

}
